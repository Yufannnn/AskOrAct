# AskOrAct - Full Evaluation Report

**Generated:** 2026-03-13 16:41

## Setup

- **Principal cannot pick objects** (`PRINCIPAL_CAN_PICK = False`).
- **Success requires assistant to pick the true goal object.**
- **Episode deadline:** per-episode max steps = oracle shortest assistant path + margin.
- **Cost rule:** `team_cost = steps + QUESTION_COST * questions_asked`; failed episodes use `team_cost = episode_max_steps + QUESTION_COST * questions_asked`.
- **Core main-sweep policies:** AskOrAct, NeverAsk, AlwaysAsk, InfoGainAsk, RandomAsk.
- **Targeted K=2-only baselines in the main sweep:** EasyInfoGainAsk, POMCPPlanner.
- **Scale-K / ablations / answer-noise sweeps** include the full 7-policy registry.
- **Conditions:** Ambiguity K in {1, 2, 3, 4}, eps in {0.0, 0.05, 0.1}, beta in {1.0, 2.0, 4.0}.
- **Replicate seeds:** [0, 1, 2, 3, 4].
- **Episodes per (policy, K, eps, beta):** 100 (5 reps x 20 eps/rep).
- **Uncertainty:** 95% bootstrap CI over episodes (B=1000).

## Baselines

- **info_gain_ask:** computes expected entropy reduction `IG(q)=H(b)-E[H|q]` for each question and asks `argmax_q IG(q)` when IG passes threshold (and optional entropy gate), otherwise acts toward MAP goal.
- **easy_info_gain_ask:** a one-question version of `info_gain_ask`, used as a lighter ask-once baseline.
- **random_ask:** uses the same ask gating as `info_gain_ask` but picks a random available question when asking.
- **pomcp_planner:** POMCP/PO-UCT baseline that approximates POMDP ask-act planning with Monte Carlo tree search over physical and question actions.

## Conceptual Overview

### Task Setup

![Task setup overview](setup_overview.png)

### Ask-or-Act Decision Flow

![Ask-or-Act pipeline](ask_or_act_pipeline.png)

---

## Summary by condition (K, eps, beta, policy)

| K | eps | beta | Policy | Success rate | Avg steps | Avg questions | Avg regret | MAP correct |
|---|-----|------|--------|--------------|-----------|---------------|------------|-------------|
| 1 | 0.0 | 1.0 | always_ask | 100.00% | 6.7 | 0.00 | 0.58 | 100.00% |
| 1 | 0.0 | 1.0 | ask_or_act | 100.00% | 6.7 | 0.00 | 0.58 | 100.00% |
| 1 | 0.0 | 1.0 | info_gain_ask | 100.00% | 6.7 | 0.00 | 0.58 | 100.00% |
| 1 | 0.0 | 1.0 | never_ask | 100.00% | 6.7 | 0.00 | 0.58 | 100.00% |
| 1 | 0.0 | 1.0 | random_ask | 100.00% | 6.7 | 0.00 | 0.58 | 100.00% |
| 1 | 0.0 | 2.0 | always_ask | 100.00% | 6.6 | 0.00 | 0.55 | 100.00% |
| 1 | 0.0 | 2.0 | ask_or_act | 100.00% | 6.6 | 0.00 | 0.55 | 100.00% |
| 1 | 0.0 | 2.0 | info_gain_ask | 100.00% | 6.6 | 0.00 | 0.55 | 100.00% |
| 1 | 0.0 | 2.0 | never_ask | 100.00% | 6.6 | 0.00 | 0.55 | 100.00% |
| 1 | 0.0 | 2.0 | random_ask | 100.00% | 6.6 | 0.00 | 0.55 | 100.00% |
| 1 | 0.0 | 4.0 | always_ask | 100.00% | 7.0 | 0.00 | 0.53 | 100.00% |
| 1 | 0.0 | 4.0 | ask_or_act | 100.00% | 7.0 | 0.00 | 0.53 | 100.00% |
| 1 | 0.0 | 4.0 | info_gain_ask | 100.00% | 7.0 | 0.00 | 0.53 | 100.00% |
| 1 | 0.0 | 4.0 | never_ask | 100.00% | 7.0 | 0.00 | 0.53 | 100.00% |
| 1 | 0.0 | 4.0 | random_ask | 100.00% | 7.0 | 0.00 | 0.53 | 100.00% |
| 1 | 0.05 | 1.0 | always_ask | 100.00% | 6.9 | 0.00 | 0.57 | 100.00% |
| 1 | 0.05 | 1.0 | ask_or_act | 100.00% | 6.9 | 0.00 | 0.57 | 100.00% |
| 1 | 0.05 | 1.0 | info_gain_ask | 100.00% | 6.9 | 0.00 | 0.57 | 100.00% |
| 1 | 0.05 | 1.0 | never_ask | 100.00% | 6.9 | 0.00 | 0.57 | 100.00% |
| 1 | 0.05 | 1.0 | random_ask | 100.00% | 6.9 | 0.00 | 0.57 | 100.00% |
| 1 | 0.05 | 2.0 | always_ask | 100.00% | 7.0 | 0.00 | 0.49 | 100.00% |
| 1 | 0.05 | 2.0 | ask_or_act | 100.00% | 7.0 | 0.00 | 0.49 | 100.00% |
| 1 | 0.05 | 2.0 | info_gain_ask | 100.00% | 7.0 | 0.00 | 0.49 | 100.00% |
| 1 | 0.05 | 2.0 | never_ask | 100.00% | 7.0 | 0.00 | 0.49 | 100.00% |
| 1 | 0.05 | 2.0 | random_ask | 100.00% | 7.0 | 0.00 | 0.49 | 100.00% |
| 1 | 0.05 | 4.0 | always_ask | 100.00% | 7.3 | 0.00 | 0.54 | 100.00% |
| 1 | 0.05 | 4.0 | ask_or_act | 100.00% | 7.3 | 0.00 | 0.54 | 100.00% |
| 1 | 0.05 | 4.0 | info_gain_ask | 100.00% | 7.3 | 0.00 | 0.54 | 100.00% |
| 1 | 0.05 | 4.0 | never_ask | 100.00% | 7.3 | 0.00 | 0.54 | 100.00% |
| 1 | 0.05 | 4.0 | random_ask | 100.00% | 7.3 | 0.00 | 0.54 | 100.00% |
| 1 | 0.1 | 1.0 | always_ask | 100.00% | 7.2 | 0.00 | 0.59 | 100.00% |
| 1 | 0.1 | 1.0 | ask_or_act | 100.00% | 7.2 | 0.00 | 0.59 | 100.00% |
| 1 | 0.1 | 1.0 | info_gain_ask | 100.00% | 7.2 | 0.00 | 0.59 | 100.00% |
| 1 | 0.1 | 1.0 | never_ask | 100.00% | 7.2 | 0.00 | 0.59 | 100.00% |
| 1 | 0.1 | 1.0 | random_ask | 100.00% | 7.2 | 0.00 | 0.59 | 100.00% |
| 1 | 0.1 | 2.0 | always_ask | 100.00% | 6.2 | 0.00 | 0.46 | 100.00% |
| 1 | 0.1 | 2.0 | ask_or_act | 100.00% | 6.2 | 0.00 | 0.46 | 100.00% |
| 1 | 0.1 | 2.0 | info_gain_ask | 100.00% | 6.2 | 0.00 | 0.46 | 100.00% |
| 1 | 0.1 | 2.0 | never_ask | 100.00% | 6.2 | 0.00 | 0.46 | 100.00% |
| 1 | 0.1 | 2.0 | random_ask | 100.00% | 6.2 | 0.00 | 0.46 | 100.00% |
| 1 | 0.1 | 4.0 | always_ask | 100.00% | 6.1 | 0.00 | 0.42 | 100.00% |
| 1 | 0.1 | 4.0 | ask_or_act | 100.00% | 6.1 | 0.00 | 0.42 | 100.00% |
| 1 | 0.1 | 4.0 | info_gain_ask | 100.00% | 6.1 | 0.00 | 0.42 | 100.00% |
| 1 | 0.1 | 4.0 | never_ask | 100.00% | 6.1 | 0.00 | 0.42 | 100.00% |
| 1 | 0.1 | 4.0 | random_ask | 100.00% | 6.1 | 0.00 | 0.42 | 100.00% |
| 2 | 0.0 | 1.0 | always_ask | 91.00% | 9.0 | 1.97 | 3.67 | 98.00% |
| 2 | 0.0 | 1.0 | ask_or_act | 97.00% | 7.8 | 0.71 | 1.84 | 98.00% |
| 2 | 0.0 | 1.0 | easy_info_gain_ask | 96.00% | 8.2 | 1.00 | 2.37 | 97.00% |
| 2 | 0.0 | 1.0 | info_gain_ask | 95.00% | 8.3 | 1.04 | 2.44 | 97.00% |
| 2 | 0.0 | 1.0 | never_ask | 85.00% | 8.5 | 0.00 | 2.16 | 95.00% |
| 2 | 0.0 | 1.0 | pomcp_planner | 95.00% | 8.6 | 0.29 | 2.38 | 96.00% |
| 2 | 0.0 | 1.0 | random_ask | 90.00% | 9.1 | 1.88 | 3.74 | 95.00% |
| 2 | 0.0 | 2.0 | always_ask | 95.00% | 9.1 | 1.91 | 3.52 | 99.00% |
| 2 | 0.0 | 2.0 | ask_or_act | 99.00% | 7.7 | 0.61 | 1.56 | 98.00% |
| 2 | 0.0 | 2.0 | easy_info_gain_ask | 98.00% | 8.2 | 1.00 | 2.24 | 100.00% |
| 2 | 0.0 | 2.0 | info_gain_ask | 98.00% | 8.3 | 1.04 | 2.33 | 100.00% |
| 2 | 0.0 | 2.0 | never_ask | 94.00% | 7.9 | 0.00 | 1.46 | 98.00% |
| 2 | 0.0 | 2.0 | pomcp_planner | 98.00% | 7.8 | 0.21 | 1.46 | 99.00% |
| 2 | 0.0 | 2.0 | random_ask | 96.00% | 9.1 | 1.85 | 3.52 | 100.00% |
| 2 | 0.0 | 4.0 | always_ask | 99.00% | 9.2 | 1.91 | 3.52 | 100.00% |
| 2 | 0.0 | 4.0 | ask_or_act | 99.00% | 7.8 | 0.50 | 1.41 | 98.00% |
| 2 | 0.0 | 4.0 | easy_info_gain_ask | 98.00% | 8.4 | 1.00 | 2.24 | 100.00% |
| 2 | 0.0 | 4.0 | info_gain_ask | 98.00% | 8.4 | 1.02 | 2.27 | 100.00% |
| 2 | 0.0 | 4.0 | never_ask | 98.00% | 7.9 | 0.00 | 1.26 | 98.00% |
| 2 | 0.0 | 4.0 | pomcp_planner | 99.00% | 7.5 | 0.12 | 0.91 | 100.00% |
| 2 | 0.0 | 4.0 | random_ask | 100.00% | 9.0 | 1.67 | 3.17 | 100.00% |
| 2 | 0.05 | 1.0 | always_ask | 94.00% | 9.1 | 1.84 | 3.34 | 95.00% |
| 2 | 0.05 | 1.0 | ask_or_act | 97.00% | 8.1 | 0.76 | 1.84 | 97.00% |
| 2 | 0.05 | 1.0 | easy_info_gain_ask | 96.00% | 8.4 | 1.00 | 2.20 | 100.00% |
| 2 | 0.05 | 1.0 | info_gain_ask | 97.00% | 8.3 | 1.05 | 2.19 | 100.00% |
| 2 | 0.05 | 1.0 | never_ask | 84.00% | 8.8 | 0.00 | 2.15 | 91.00% |
| 2 | 0.05 | 1.0 | pomcp_planner | 88.00% | 9.1 | 0.31 | 2.54 | 94.00% |
| 2 | 0.05 | 1.0 | random_ask | 88.00% | 9.4 | 1.89 | 3.63 | 96.00% |
| 2 | 0.05 | 2.0 | always_ask | 92.00% | 9.1 | 1.90 | 3.53 | 100.00% |
| 2 | 0.05 | 2.0 | ask_or_act | 94.00% | 8.0 | 0.67 | 1.82 | 99.00% |
| 2 | 0.05 | 2.0 | easy_info_gain_ask | 95.00% | 8.2 | 1.00 | 2.24 | 99.00% |
| 2 | 0.05 | 2.0 | info_gain_ask | 95.00% | 8.2 | 1.04 | 2.27 | 99.00% |
| 2 | 0.05 | 2.0 | never_ask | 90.00% | 8.2 | 0.00 | 1.69 | 98.00% |
| 2 | 0.05 | 2.0 | pomcp_planner | 94.00% | 8.0 | 0.17 | 1.60 | 99.00% |
| 2 | 0.05 | 2.0 | random_ask | 92.00% | 8.9 | 1.75 | 3.31 | 100.00% |
| 2 | 0.05 | 4.0 | always_ask | 98.00% | 8.6 | 1.73 | 3.12 | 99.00% |
| 2 | 0.05 | 4.0 | ask_or_act | 99.00% | 7.5 | 0.64 | 1.51 | 97.00% |
| 2 | 0.05 | 4.0 | easy_info_gain_ask | 100.00% | 7.9 | 1.00 | 2.03 | 99.00% |
| 2 | 0.05 | 4.0 | info_gain_ask | 100.00% | 7.9 | 1.00 | 2.03 | 99.00% |
| 2 | 0.05 | 4.0 | never_ask | 93.00% | 7.8 | 0.00 | 1.49 | 98.00% |
| 2 | 0.05 | 4.0 | pomcp_planner | 100.00% | 7.6 | 0.27 | 1.34 | 99.00% |
| 2 | 0.05 | 4.0 | random_ask | 95.00% | 8.9 | 1.82 | 3.43 | 98.00% |
| 2 | 0.1 | 1.0 | always_ask | 90.00% | 8.7 | 1.86 | 3.53 | 95.00% |
| 2 | 0.1 | 1.0 | ask_or_act | 90.00% | 7.8 | 0.70 | 2.04 | 97.00% |
| 2 | 0.1 | 1.0 | easy_info_gain_ask | 93.00% | 7.9 | 1.00 | 2.29 | 97.00% |
| 2 | 0.1 | 1.0 | info_gain_ask | 93.00% | 7.9 | 1.06 | 2.35 | 98.00% |
| 2 | 0.1 | 1.0 | never_ask | 85.00% | 8.0 | 0.00 | 1.92 | 96.00% |
| 2 | 0.1 | 1.0 | pomcp_planner | 94.00% | 8.6 | 0.39 | 2.71 | 95.00% |
| 2 | 0.1 | 1.0 | random_ask | 90.00% | 8.8 | 1.82 | 3.55 | 96.00% |
| 2 | 0.1 | 2.0 | always_ask | 95.00% | 8.8 | 1.68 | 3.14 | 100.00% |
| 2 | 0.1 | 2.0 | ask_or_act | 96.00% | 7.9 | 0.69 | 1.80 | 99.00% |
| 2 | 0.1 | 2.0 | easy_info_gain_ask | 99.00% | 8.0 | 1.00 | 2.04 | 99.00% |
| 2 | 0.1 | 2.0 | info_gain_ask | 100.00% | 8.1 | 1.09 | 2.15 | 99.00% |
| 2 | 0.1 | 2.0 | never_ask | 96.00% | 8.0 | 0.00 | 1.56 | 97.00% |
| 2 | 0.1 | 2.0 | pomcp_planner | 95.00% | 8.2 | 0.18 | 1.79 | 100.00% |
| 2 | 0.1 | 2.0 | random_ask | 95.00% | 9.0 | 1.75 | 3.35 | 100.00% |
| 2 | 0.1 | 4.0 | always_ask | 97.00% | 8.5 | 2.07 | 3.56 | 99.00% |
| 2 | 0.1 | 4.0 | ask_or_act | 99.00% | 7.2 | 0.57 | 1.50 | 98.00% |
| 2 | 0.1 | 4.0 | easy_info_gain_ask | 96.00% | 7.7 | 1.00 | 2.18 | 99.00% |
| 2 | 0.1 | 4.0 | info_gain_ask | 96.00% | 7.7 | 1.07 | 2.23 | 99.00% |
| 2 | 0.1 | 4.0 | never_ask | 95.00% | 7.3 | 0.00 | 1.32 | 98.00% |
| 2 | 0.1 | 4.0 | pomcp_planner | 97.00% | 7.5 | 0.19 | 1.60 | 99.00% |
| 2 | 0.1 | 4.0 | random_ask | 96.00% | 8.3 | 1.85 | 3.27 | 99.00% |
| 3 | 0.0 | 1.0 | always_ask | 87.00% | 9.2 | 2.41 | 4.14 | 98.00% |
| 3 | 0.0 | 1.0 | ask_or_act | 90.00% | 8.1 | 0.74 | 2.19 | 95.00% |
| 3 | 0.0 | 1.0 | info_gain_ask | 93.00% | 8.2 | 1.25 | 2.58 | 98.00% |
| 3 | 0.0 | 1.0 | never_ask | 76.00% | 8.8 | 0.00 | 2.51 | 91.00% |
| 3 | 0.0 | 1.0 | random_ask | 92.00% | 8.8 | 1.96 | 3.56 | 100.00% |
| 3 | 0.0 | 2.0 | always_ask | 89.00% | 9.1 | 2.28 | 3.99 | 99.00% |
| 3 | 0.0 | 2.0 | ask_or_act | 90.00% | 8.1 | 0.66 | 2.19 | 99.00% |
| 3 | 0.0 | 2.0 | info_gain_ask | 92.00% | 8.2 | 1.23 | 2.60 | 100.00% |
| 3 | 0.0 | 2.0 | never_ask | 91.00% | 8.2 | 0.00 | 2.02 | 98.00% |
| 3 | 0.0 | 2.0 | random_ask | 90.00% | 8.8 | 1.87 | 3.52 | 100.00% |
| 3 | 0.0 | 4.0 | always_ask | 94.00% | 9.3 | 2.41 | 4.14 | 99.00% |
| 3 | 0.0 | 4.0 | ask_or_act | 93.00% | 7.9 | 0.55 | 1.86 | 100.00% |
| 3 | 0.0 | 4.0 | info_gain_ask | 98.00% | 8.1 | 1.20 | 2.37 | 100.00% |
| 3 | 0.0 | 4.0 | never_ask | 85.00% | 8.3 | 0.00 | 1.94 | 98.00% |
| 3 | 0.0 | 4.0 | random_ask | 98.00% | 8.9 | 1.95 | 3.52 | 100.00% |
| 3 | 0.05 | 1.0 | always_ask | 87.00% | 9.7 | 2.28 | 4.19 | 98.00% |
| 3 | 0.05 | 1.0 | ask_or_act | 86.00% | 8.7 | 0.76 | 2.47 | 91.00% |
| 3 | 0.05 | 1.0 | info_gain_ask | 91.00% | 8.8 | 1.22 | 2.79 | 98.00% |
| 3 | 0.05 | 1.0 | never_ask | 76.00% | 9.2 | 0.00 | 2.59 | 83.00% |
| 3 | 0.05 | 1.0 | random_ask | 88.00% | 9.5 | 1.99 | 3.90 | 98.00% |
| 3 | 0.05 | 2.0 | always_ask | 88.00% | 10.2 | 2.36 | 4.34 | 98.00% |
| 3 | 0.05 | 2.0 | ask_or_act | 91.00% | 9.0 | 0.61 | 2.23 | 96.00% |
| 3 | 0.05 | 2.0 | info_gain_ask | 95.00% | 9.3 | 1.23 | 2.83 | 99.00% |
| 3 | 0.05 | 2.0 | never_ask | 84.00% | 9.2 | 0.00 | 2.20 | 96.00% |
| 3 | 0.05 | 2.0 | random_ask | 93.00% | 9.9 | 1.93 | 3.83 | 98.00% |
| 3 | 0.05 | 4.0 | always_ask | 91.00% | 9.2 | 2.18 | 3.89 | 98.00% |
| 3 | 0.05 | 4.0 | ask_or_act | 93.00% | 8.2 | 0.65 | 2.08 | 98.00% |
| 3 | 0.05 | 4.0 | info_gain_ask | 96.00% | 8.4 | 1.21 | 2.62 | 100.00% |
| 3 | 0.05 | 4.0 | never_ask | 91.00% | 8.2 | 0.00 | 1.75 | 98.00% |
| 3 | 0.05 | 4.0 | random_ask | 94.00% | 9.2 | 2.05 | 3.75 | 98.00% |
| 3 | 0.1 | 1.0 | always_ask | 91.00% | 9.2 | 2.12 | 3.85 | 95.00% |
| 3 | 0.1 | 1.0 | ask_or_act | 94.00% | 8.2 | 0.76 | 2.18 | 98.00% |
| 3 | 0.1 | 1.0 | info_gain_ask | 95.00% | 8.4 | 1.22 | 2.63 | 99.00% |
| 3 | 0.1 | 1.0 | never_ask | 78.00% | 8.7 | 0.00 | 2.34 | 94.00% |
| 3 | 0.1 | 1.0 | random_ask | 94.00% | 9.2 | 2.07 | 3.87 | 98.00% |
| 3 | 0.1 | 2.0 | always_ask | 94.00% | 9.5 | 2.34 | 4.11 | 98.00% |
| 3 | 0.1 | 2.0 | ask_or_act | 94.00% | 8.2 | 0.61 | 1.97 | 98.00% |
| 3 | 0.1 | 2.0 | info_gain_ask | 97.00% | 8.5 | 1.21 | 2.56 | 99.00% |
| 3 | 0.1 | 2.0 | never_ask | 88.00% | 8.4 | 0.00 | 1.84 | 95.00% |
| 3 | 0.1 | 2.0 | random_ask | 96.00% | 9.1 | 1.85 | 3.50 | 98.00% |
| 3 | 0.1 | 4.0 | always_ask | 91.00% | 9.3 | 2.26 | 4.02 | 98.00% |
| 3 | 0.1 | 4.0 | ask_or_act | 94.00% | 8.2 | 0.65 | 2.08 | 96.00% |
| 3 | 0.1 | 4.0 | info_gain_ask | 96.00% | 8.4 | 1.16 | 2.52 | 100.00% |
| 3 | 0.1 | 4.0 | never_ask | 85.00% | 8.6 | 0.00 | 2.15 | 95.00% |
| 3 | 0.1 | 4.0 | random_ask | 94.00% | 9.1 | 1.96 | 3.60 | 99.00% |
| 4 | 0.0 | 1.0 | always_ask | 83.00% | 10.0 | 2.50 | 4.47 | 95.00% |
| 4 | 0.0 | 1.0 | ask_or_act | 80.00% | 9.3 | 0.68 | 2.84 | 91.00% |
| 4 | 0.0 | 1.0 | info_gain_ask | 92.00% | 9.1 | 1.37 | 3.00 | 98.00% |
| 4 | 0.0 | 1.0 | never_ask | 66.00% | 9.6 | 0.00 | 2.78 | 92.00% |
| 4 | 0.0 | 1.0 | random_ask | 90.00% | 9.9 | 2.27 | 4.21 | 97.00% |
| 4 | 0.0 | 2.0 | always_ask | 92.00% | 10.1 | 2.62 | 4.53 | 98.00% |
| 4 | 0.0 | 2.0 | ask_or_act | 93.00% | 8.6 | 0.47 | 1.92 | 96.00% |
| 4 | 0.0 | 2.0 | info_gain_ask | 96.00% | 9.0 | 1.32 | 2.75 | 97.00% |
| 4 | 0.0 | 2.0 | never_ask | 86.00% | 9.0 | 0.00 | 2.08 | 97.00% |
| 4 | 0.0 | 2.0 | random_ask | 95.00% | 9.7 | 2.11 | 3.81 | 98.00% |
| 4 | 0.0 | 4.0 | always_ask | 94.00% | 9.9 | 2.52 | 4.43 | 100.00% |
| 4 | 0.0 | 4.0 | ask_or_act | 95.00% | 8.4 | 0.50 | 1.89 | 99.00% |
| 4 | 0.0 | 4.0 | info_gain_ask | 99.00% | 8.8 | 1.35 | 2.75 | 100.00% |
| 4 | 0.0 | 4.0 | never_ask | 90.00% | 8.5 | 0.00 | 1.81 | 99.00% |
| 4 | 0.0 | 4.0 | random_ask | 97.00% | 9.5 | 2.12 | 3.87 | 100.00% |
| 4 | 0.05 | 1.0 | always_ask | 84.00% | 10.1 | 2.59 | 4.63 | 98.00% |
| 4 | 0.05 | 1.0 | ask_or_act | 77.00% | 9.2 | 0.74 | 2.76 | 95.00% |
| 4 | 0.05 | 1.0 | info_gain_ask | 88.00% | 9.0 | 1.28 | 2.85 | 98.00% |
| 4 | 0.05 | 1.0 | never_ask | 68.00% | 9.6 | 0.00 | 2.78 | 85.00% |
| 4 | 0.05 | 1.0 | random_ask | 83.00% | 9.8 | 2.05 | 4.07 | 100.00% |
| 4 | 0.05 | 2.0 | always_ask | 89.00% | 10.1 | 2.51 | 4.46 | 98.00% |
| 4 | 0.05 | 2.0 | ask_or_act | 89.00% | 8.9 | 0.56 | 2.32 | 100.00% |
| 4 | 0.05 | 2.0 | info_gain_ask | 91.00% | 9.1 | 1.27 | 2.85 | 100.00% |
| 4 | 0.05 | 2.0 | never_ask | 83.00% | 9.1 | 0.00 | 2.23 | 95.00% |
| 4 | 0.05 | 2.0 | random_ask | 90.00% | 9.8 | 2.11 | 3.92 | 98.00% |
| 4 | 0.05 | 4.0 | always_ask | 90.00% | 9.8 | 2.62 | 4.62 | 100.00% |
| 4 | 0.05 | 4.0 | ask_or_act | 96.00% | 8.4 | 0.52 | 2.22 | 98.00% |
| 4 | 0.05 | 4.0 | info_gain_ask | 98.00% | 8.6 | 1.24 | 2.73 | 100.00% |
| 4 | 0.05 | 4.0 | never_ask | 95.00% | 8.4 | 0.00 | 1.98 | 98.00% |
| 4 | 0.05 | 4.0 | random_ask | 92.00% | 9.3 | 2.07 | 3.88 | 100.00% |
| 4 | 0.1 | 1.0 | always_ask | 77.00% | 9.5 | 2.64 | 4.74 | 96.00% |
| 4 | 0.1 | 1.0 | ask_or_act | 77.00% | 8.7 | 0.85 | 3.00 | 96.00% |
| 4 | 0.1 | 1.0 | info_gain_ask | 83.00% | 8.5 | 1.31 | 3.10 | 98.00% |
| 4 | 0.1 | 1.0 | never_ask | 60.00% | 9.3 | 0.00 | 3.21 | 88.00% |
| 4 | 0.1 | 1.0 | random_ask | 81.00% | 9.2 | 2.11 | 4.17 | 98.00% |
| 4 | 0.1 | 2.0 | always_ask | 85.00% | 9.5 | 2.56 | 4.53 | 100.00% |
| 4 | 0.1 | 2.0 | ask_or_act | 88.00% | 8.3 | 0.58 | 2.34 | 97.00% |
| 4 | 0.1 | 2.0 | info_gain_ask | 89.00% | 8.5 | 1.29 | 2.90 | 99.00% |
| 4 | 0.1 | 2.0 | never_ask | 76.00% | 8.7 | 0.00 | 2.45 | 93.00% |
| 4 | 0.1 | 2.0 | random_ask | 87.00% | 9.3 | 2.17 | 4.12 | 100.00% |
| 4 | 0.1 | 4.0 | always_ask | 84.00% | 9.6 | 2.62 | 4.64 | 97.00% |
| 4 | 0.1 | 4.0 | ask_or_act | 91.00% | 8.4 | 0.60 | 2.48 | 97.00% |
| 4 | 0.1 | 4.0 | info_gain_ask | 89.00% | 8.5 | 1.33 | 2.94 | 99.00% |
| 4 | 0.1 | 4.0 | never_ask | 86.00% | 8.6 | 0.00 | 2.32 | 97.00% |
| 4 | 0.1 | 4.0 | random_ask | 91.00% | 9.2 | 2.06 | 3.93 | 97.00% |

## Figures

### Main Dashboard

![Main dashboard](main_dashboard.png)

### Clarification Quality

![Clarification quality entropy delta](clarification_quality_entropy_delta.png)

### Pareto (K=4)

![Pareto K=4](pareto_K4.png)

### Ablations Dashboard

![Ablations dashboard](ablations_dashboard.png)

### Robustness: Answer Noise Deltas

![Robust answer noise deltas](robust_answer_noise_deltas.png)

### Robustness: Principal-Model Mismatch Deltas

![Robust mismatch deltas](robust_mismatch_deltas.png)

### Generalization: Held-out Templates

![Held-out template generalization](generalization_templates_plot.png)

### Generalization: Scale K to 6

![Scale-K stress test](scaleK_plot.png)


---

## Aggregate by K (averaged over eps and beta)

| K | Policy | Success rate | Avg steps | Avg questions | Avg regret | MAP correct |
|---|--------|--------------|-----------|---------------|------------|-------------|
| 1 | always_ask | 100.00% | 6.8 | 0.00 | 0.53 | 100.00% |
| 1 | ask_or_act | 100.00% | 6.8 | 0.00 | 0.53 | 100.00% |
| 1 | info_gain_ask | 100.00% | 6.8 | 0.00 | 0.53 | 100.00% |
| 1 | never_ask | 100.00% | 6.8 | 0.00 | 0.53 | 100.00% |
| 1 | random_ask | 100.00% | 6.8 | 0.00 | 0.53 | 100.00% |
| 2 | always_ask | 94.56% | 8.9 | 1.87 | 3.44 | 98.33% |
| 2 | ask_or_act | 96.67% | 7.8 | 0.65 | 1.70 | 97.89% |
| 2 | easy_info_gain_ask | 96.78% | 8.1 | 1.00 | 2.20 | 98.89% |
| 2 | info_gain_ask | 96.89% | 8.1 | 1.05 | 2.25 | 99.00% |
| 2 | never_ask | 91.11% | 8.1 | 0.00 | 1.67 | 96.56% |
| 2 | pomcp_planner | 95.56% | 8.1 | 0.24 | 1.82 | 97.89% |
| 2 | random_ask | 93.56% | 8.9 | 1.81 | 3.44 | 98.22% |
| 3 | always_ask | 90.22% | 9.4 | 2.29 | 4.08 | 97.89% |
| 3 | ask_or_act | 91.67% | 8.3 | 0.67 | 2.14 | 96.78% |
| 3 | info_gain_ask | 94.78% | 8.5 | 1.21 | 2.61 | 99.22% |
| 3 | never_ask | 83.78% | 8.6 | 0.00 | 2.15 | 94.22% |
| 3 | random_ask | 93.22% | 9.2 | 1.96 | 3.67 | 98.78% |
| 4 | always_ask | 86.44% | 9.9 | 2.58 | 4.56 | 98.00% |
| 4 | ask_or_act | 87.33% | 8.7 | 0.61 | 2.42 | 96.56% |
| 4 | info_gain_ask | 91.67% | 8.8 | 1.31 | 2.88 | 98.78% |
| 4 | never_ask | 78.89% | 9.0 | 0.00 | 2.40 | 93.78% |
| 4 | random_ask | 89.56% | 9.5 | 2.12 | 4.00 | 98.67% |

---

## High-Ambiguity Snapshot (K=3,4)

- **always_ask:** success 88.33%, avg regret 4.32, avg questions 2.43.
- **ask_or_act:** success 89.50%, avg regret 2.28, avg questions 0.64.
- **info_gain_ask:** success 93.22%, avg regret 2.74, avg questions 1.26.
- **never_ask:** success 81.33%, avg regret 2.28, avg questions 0.00.
- **random_ask:** success 91.39%, avg regret 3.83, avg questions 2.04.

## Clarification Quality (First Asked Question)

We summarize posterior contraction from the first asked question using entropy and effective goal count.

| Policy | Ask rate (K=3,4) | H_before | H_after | DeltaH | N_eff_before | N_eff_after | DeltaN_eff | IG_first |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| always_ask | 100.00% | 1.242 | 0.751 | 0.492 | 3.500 | 2.352 | 1.148 | 0.492 |
| ask_or_act | 63.22% | 1.209 | 0.755 | 0.454 | 3.354 | 2.358 | 0.996 | 0.460 |
| info_gain_ask | 100.00% | 1.242 | 0.497 | 0.745 | 3.500 | 1.734 | 1.766 | 0.746 |
| never_ask | 0.00% | 1.242 | 1.242 | 0.000 | 3.500 | 3.500 | 0.000 | 0.000 |
| random_ask | 100.00% | 1.242 | 0.877 | 0.366 | 3.500 | 2.629 | 0.871 | 0.361 |

Interpretation: `info_gain_ask` achieves the largest average first-question entropy reduction among policies that ask at K=3-4.

## Robustness Summary (K=3,4)

All results are averaged over replicate seeds; uncertainty is 95% bootstrap CI over episodes.

| K | Policy | Success (mean [95% CI]) | Regret (mean [95% CI]) | Questions (mean [95% CI]) |
|---|--------|--------------------------|-------------------------|----------------------------|
| 3 | always_ask | 90.22% [88.33%, 92.11%] | 4.08 [3.97, 4.19] | 2.29 [2.23, 2.35] |
| 3 | ask_or_act | 91.67% [89.78%, 93.44%] | 2.14 [2.05, 2.25] | 0.67 [0.63, 0.70] |
| 3 | info_gain_ask | 94.78% [93.33%, 96.22%] | 2.61 [2.54, 2.69] | 1.21 [1.19, 1.24] |
| 3 | never_ask | 83.78% [81.22%, 86.22%] | 2.15 [2.02, 2.27] | 0.00 [0.00, 0.00] |
| 3 | random_ask | 93.22% [91.66%, 94.67%] | 3.67 [3.58, 3.77] | 1.96 [1.91, 2.01] |
| 4 | always_ask | 86.44% [84.00%, 88.34%] | 4.56 [4.46, 4.66] | 2.58 [2.52, 2.62] |
| 4 | ask_or_act | 87.33% [85.11%, 89.34%] | 2.42 [2.30, 2.53] | 0.61 [0.58, 0.64] |
| 4 | info_gain_ask | 91.67% [89.67%, 93.33%] | 2.88 [2.79, 2.96] | 1.31 [1.27, 1.34] |
| 4 | never_ask | 78.89% [75.89%, 81.34%] | 2.40 [2.28, 2.53] | 0.00 [0.00, 0.00] |
| 4 | random_ask | 89.56% [87.44%, 91.33%] | 4.00 [3.90, 4.09] | 2.12 [2.06, 2.17] |

## Policy Difference CIs (K=3,4)

Deltas are bootstrap-estimated on paired episode keys: (K, eps, beta, rep_seed, episode_id).
Contrasts are reported only when the compared baseline was actually evaluated in the main sweep at K=3,4.

| Contrast | Delta mean [95% CI] | N paired episodes |
|----------|-----------------------|-------------------|
| DeltaSuccess (AskOrAct - NeverAsk) | 8.17% [6.61%, 9.78%] | 1800 |
| DeltaRegret (AskOrAct - AlwaysAsk) | -2.04 [-2.13, -1.95] | 1800 |
| DeltaSuccess (AskOrAct - InfoGainAsk) | -3.72% [-4.94%, -2.61%] | 1800 |
| DeltaRegret (AskOrAct - InfoGainAsk) | -0.46 [-0.53, -0.40] | 1800 |
| DeltaSuccess (AskOrAct - EasyInfoGainAsk) | Not evaluated in main sweep at K=3,4 | 0 |
| DeltaRegret (AskOrAct - EasyInfoGainAsk) | Not evaluated in main sweep at K=3,4 | 0 |
| DeltaSuccess (AskOrAct - POMCP) | Not evaluated in main sweep at K=3,4 | 0 |
| DeltaRegret (AskOrAct - POMCP) | Not evaluated in main sweep at K=3,4 | 0 |

IG is best at entropy reduction; VoI is best at minimizing team cost under deadlines; POMCP approximates POMDP planning and serves as a stronger baseline.

## Robustness Sweeps (K=3,4)

Robustness is summarized with paired deltas and bootstrap CIs under answer-noise shifts and principal-model mismatch.

### Answer-Noise Robustness

| answer_noise | DeltaSuccess (AskOrAct - NeverAsk) | DeltaRegret (AskOrAct - AlwaysAsk) |
|---:|---:|---:|
| 0.0 | 5.50% [1.00%, 10.00%] | -2.16 [-2.42, -1.88] |
| 0.1 | 1.50% [-2.50%, 5.50%] | -2.57 [-2.81, -2.33] |
| 0.2 | 2.50% [-1.00%, 6.50%] | -2.96 [-3.19, -2.73] |

Trend: AskOrAct keeps a positive success advantage vs NeverAsk and a strong regret advantage vs AlwaysAsk as answer noise increases.

### Principal-Model Mismatch Robustness

| principal_beta | DeltaSuccess (AskOrAct - NeverAsk) | DeltaRegret (AskOrAct - AlwaysAsk) |
|---:|---:|---:|
| 1.0 | 13.50% [8.00%, 19.50%] | -1.69 [-1.98, -1.37] |
| 2.0 | 4.00% [0.50%, 7.50%] | -2.12 [-2.40, -1.86] |
| 4.0 | 6.00% [2.50%, 9.50%] | -2.37 [-2.63, -2.10] |

Trend: AskOrAct remains robust to principal rationality mismatch, preserving positive success deltas and negative regret deltas.

## Held-out Template Generalization

Evaluation uses only held-out instruction templates (deterministic 70/30 split over template IDs), with the same K/eps/beta grids.

| K | Policy | Success [95% CI] | Regret [95% CI] | Questions [95% CI] |
|---|---|---|---|---|
| 1 | ask_or_act | 100.00% [100.00%, 100.00%] | 0.52 [0.47, 0.57] | 0.00 [0.00, 0.00] |
| 1 | easy_info_gain_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.47, 0.57] | 0.00 [0.00, 0.00] |
| 1 | info_gain_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.47, 0.57] | 0.00 [0.00, 0.00] |
| 1 | random_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.47, 0.57] | 0.00 [0.00, 0.00] |
| 2 | ask_or_act | 91.56% [89.78%, 93.22%] | 1.64 [1.52, 1.75] | 0.00 [0.00, 0.00] |
| 2 | easy_info_gain_ask | 96.89% [95.78%, 98.00%] | 2.20 [2.13, 2.26] | 1.00 [1.00, 1.00] |
| 2 | info_gain_ask | 96.33% [95.11%, 97.56%] | 2.31 [2.24, 2.38] | 1.09 [1.08, 1.11] |
| 2 | random_ask | 94.33% [92.89%, 95.78%] | 3.32 [3.22, 3.42] | 1.76 [1.71, 1.81] |
| 3 | ask_or_act | 89.44% [87.33%, 91.44%] | 2.22 [2.10, 2.34] | 0.53 [0.50, 0.57] |
| 3 | easy_info_gain_ask | 87.89% [85.89%, 89.89%] | 2.72 [2.63, 2.82] | 1.00 [1.00, 1.00] |
| 3 | info_gain_ask | 88.89% [86.89%, 91.00%] | 3.80 [3.73, 3.88] | 1.88 [1.86, 1.91] |
| 3 | random_ask | 86.22% [83.89%, 88.33%] | 4.79 [4.71, 4.87] | 2.63 [2.60, 2.67] |
| 4 | ask_or_act | 83.89% [81.33%, 86.22%] | 2.55 [2.42, 2.68] | 0.60 [0.56, 0.64] |
| 4 | easy_info_gain_ask | 82.11% [79.33%, 84.67%] | 2.97 [2.87, 3.07] | 1.00 [1.00, 1.00] |
| 4 | info_gain_ask | 86.22% [83.78%, 88.56%] | 3.91 [3.83, 3.98] | 1.96 [1.95, 1.97] |
| 4 | random_ask | 82.22% [79.56%, 84.56%] | 4.82 [4.74, 4.90] | 2.65 [2.61, 2.68] |

Summary: performance degrades gracefully under unseen templates, with no catastrophic collapse in success or regret trends.

## Scale-K Stress Test (K up to 6)

Evaluation fixes `eps=0.05` and `beta=2.0`, extending ambiguity to `K=5,6`.

| K | Policy | Success [95% CI] | Regret [95% CI] | Questions [95% CI] |
|---|---|---|---|---|
| 1 | always_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 1 | ask_or_act | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 1 | easy_info_gain_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 1 | info_gain_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 1 | never_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 1 | pomcp_planner | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 1 | random_ask | 100.00% [100.00%, 100.00%] | 0.52 [0.39, 0.65] | 0.00 [0.00, 0.00] |
| 2 | always_ask | 95.00% [90.00%, 99.00%] | 3.60 [3.25, 3.91] | 1.95 [1.77, 2.14] |
| 2 | ask_or_act | 93.00% [88.00%, 98.00%] | 1.67 [1.33, 2.04] | 0.00 [0.00, 0.00] |
| 2 | easy_info_gain_ask | 97.00% [94.00%, 100.00%] | 2.28 [2.09, 2.48] | 1.00 [1.00, 1.00] |
| 2 | info_gain_ask | 98.00% [95.00%, 100.00%] | 2.28 [2.09, 2.46] | 1.02 [1.00, 1.05] |
| 2 | never_ask | 93.00% [88.00%, 98.00%] | 1.67 [1.33, 2.04] | 0.00 [0.00, 0.00] |
| 2 | pomcp_planner | 94.00% [89.00%, 98.00%] | 2.52 [2.18, 2.86] | 0.37 [0.26, 0.49] |
| 2 | random_ask | 92.00% [86.00%, 97.00%] | 3.42 [3.13, 3.73] | 1.75 [1.61, 1.90] |
| 3 | always_ask | 85.00% [77.00%, 91.02%] | 4.86 [4.60, 5.11] | 2.76 [2.64, 2.86] |
| 3 | ask_or_act | 87.00% [80.00%, 93.00%] | 2.19 [1.84, 2.54] | 0.51 [0.41, 0.61] |
| 3 | easy_info_gain_ask | 87.00% [80.00%, 93.00%] | 2.68 [2.41, 2.98] | 1.00 [1.00, 1.00] |
| 3 | info_gain_ask | 86.00% [79.00%, 92.00%] | 3.21 [2.93, 3.51] | 1.45 [1.36, 1.55] |
| 3 | never_ask | 82.00% [74.00%, 89.00%] | 2.21 [1.84, 2.59] | 0.00 [0.00, 0.00] |
| 3 | pomcp_planner | 86.00% [79.00%, 93.00%] | 3.08 [2.71, 3.44] | 0.55 [0.42, 0.69] |
| 3 | random_ask | 83.00% [75.00%, 90.00%] | 4.42 [4.14, 4.70] | 2.41 [2.27, 2.55] |
| 4 | always_ask | 82.00% [75.00%, 89.00%] | 4.95 [4.67, 5.21] | 2.76 [2.65, 2.88] |
| 4 | ask_or_act | 89.00% [83.00%, 95.00%] | 2.28 [1.96, 2.62] | 0.52 [0.43, 0.63] |
| 4 | easy_info_gain_ask | 92.00% [87.00%, 97.00%] | 2.83 [2.57, 3.11] | 1.00 [1.00, 1.00] |
| 4 | info_gain_ask | 90.00% [84.00%, 95.00%] | 3.35 [3.06, 3.65] | 1.52 [1.42, 1.62] |
| 4 | never_ask | 84.00% [76.00%, 91.00%] | 2.13 [1.76, 2.49] | 0.00 [0.00, 0.00] |
| 4 | pomcp_planner | 75.00% [66.00%, 83.00%] | 3.65 [3.31, 3.99] | 0.66 [0.51, 0.81] |
| 4 | random_ask | 89.00% [83.00%, 95.00%] | 4.47 [4.21, 4.74] | 2.39 [2.25, 2.53] |
| 5 | always_ask | 82.00% [74.00%, 89.00%] | 5.25 [5.07, 5.42] | 2.95 [2.89, 3.00] |
| 5 | ask_or_act | 91.00% [85.00%, 96.00%] | 2.42 [2.06, 2.76] | 0.61 [0.49, 0.71] |
| 5 | easy_info_gain_ask | 86.00% [78.00%, 92.00%] | 2.96 [2.69, 3.25] | 1.00 [1.00, 1.00] |
| 5 | info_gain_ask | 88.00% [81.00%, 94.00%] | 3.51 [3.22, 3.79] | 1.62 [1.53, 1.71] |
| 5 | never_ask | 85.00% [77.00%, 92.00%] | 2.34 [1.96, 2.70] | 0.00 [0.00, 0.00] |
| 5 | pomcp_planner | 74.00% [65.00%, 82.00%] | 3.85 [3.51, 4.16] | 0.67 [0.53, 0.84] |
| 5 | random_ask | 79.00% [70.00%, 86.02%] | 4.75 [4.47, 5.00] | 2.53 [2.39, 2.65] |
| 6 | always_ask | 64.00% [54.00%, 73.00%] | 5.61 [5.43, 5.78] | 3.00 [3.00, 3.00] |
| 6 | ask_or_act | 80.00% [72.00%, 88.00%] | 2.58 [2.21, 2.95] | 0.59 [0.48, 0.70] |
| 6 | easy_info_gain_ask | 71.00% [62.00%, 80.00%] | 3.43 [3.10, 3.75] | 1.00 [1.00, 1.00] |
| 6 | info_gain_ask | 73.00% [63.00%, 81.00%] | 4.12 [3.86, 4.38] | 1.65 [1.55, 1.74] |
| 6 | never_ask | 74.00% [66.00%, 82.00%] | 2.73 [2.37, 3.11] | 0.00 [0.00, 0.00] |
| 6 | pomcp_planner | 73.00% [64.00%, 82.00%] | 4.07 [3.72, 4.44] | 0.75 [0.60, 0.90] |
| 6 | random_ask | 69.00% [59.00%, 77.00%] | 5.07 [4.86, 5.29] | 2.57 [2.44, 2.70] |

Summary: as ambiguity increases to K=5-6, regret and question load rise as expected, but policy ordering remains broadly stable (graceful degradation).

## Failure Mode Breakdown

| K | Policy | Failure rate | failure_by_timeout rate | failure_by_wrong_pick rate |
|---|--------|--------------|-------------------------|----------------------------|
| 3 | always_ask | 9.78% | 9.78% | 0.00% |
| 3 | ask_or_act | 8.33% | 8.33% | 0.00% |
| 3 | info_gain_ask | 5.22% | 5.22% | 0.00% |
| 3 | never_ask | 16.22% | 16.22% | 0.00% |
| 3 | random_ask | 6.78% | 6.78% | 0.00% |
| 4 | always_ask | 13.56% | 13.56% | 0.00% |
| 4 | ask_or_act | 12.67% | 12.67% | 0.00% |
| 4 | info_gain_ask | 8.33% | 8.33% | 0.00% |
| 4 | never_ask | 21.11% | 21.11% | 0.00% |
| 4 | random_ask | 10.44% | 10.44% | 0.00% |

## Wrong-Pick Fail Semantics

- Main sweep keeps `WRONG_PICK_FAIL = False` for comparability.

## Ablation Notes

- **Mode A (time-only):** ASK counts as step, QUESTION_COST = 0.0.
- **Mode B (comm-cost-only):** ASK does not count as step, QUESTION_COST = 0.5.
- **Mode C (both):** ASK counts as step, QUESTION_COST = 0.5.
- This separates temporal cost from communication cost.

- **modeA (K=3,4, wrong_pick_fail=False):**
  ask_or_act -> success 80.56%, regret 2.72, questions 1.77
  never_ask -> success 85.42%, regret 2.16, questions 0.00
  always_ask -> success 76.39%, regret 3.45, questions 2.79
  info_gain_ask -> success 84.03%, regret 2.45, questions 1.47
  easy_info_gain_ask -> success 83.33%, regret 2.25, questions 1.00
  random_ask -> success 79.17%, regret 3.12, questions 2.24
  pomcp_planner -> success 88.19%, regret 2.32, questions 0.62
- **modeB (K=3,4, wrong_pick_fail=False):**
  ask_or_act -> success 84.03%, regret 2.16, questions 0.67
  never_ask -> success 82.64%, regret 2.22, questions 0.00
  always_ask -> success 90.97%, regret 2.67, questions 2.82
  info_gain_ask -> success 88.89%, regret 1.88, questions 1.53
  easy_info_gain_ask -> success 93.06%, regret 1.70, questions 1.00
  random_ask -> success 87.50%, regret 2.57, questions 2.33
  pomcp_planner -> success 97.22%, regret 2.27, questions 1.74
- **modeC (K=3,4, wrong_pick_fail=False):**
  ask_or_act -> success 81.25%, regret 2.82, questions 0.76
  never_ask -> success 84.03%, regret 1.98, questions 0.00
  always_ask -> success 72.92%, regret 4.93, questions 2.84
  info_gain_ask -> success 85.42%, regret 3.18, questions 1.53
  easy_info_gain_ask -> success 87.50%, regret 2.74, questions 1.00
  random_ask -> success 75.69%, regret 4.56, questions 2.36
  pomcp_planner -> success 90.97%, regret 2.45, questions 0.31

---

*Raw data: `results/metrics.csv`*
*Main plots: `results/main_dashboard.png`*
*Clarification quality plot: `results/clarification_quality_entropy_delta.png`*
*Ablations: `results/metrics_ablations.csv` and `results/ablations_dashboard.png`*
*Robustness plots: `results/robust_answer_noise_deltas.png`, `results/robust_mismatch_deltas.png`*
*Pareto plot: `results/pareto_K4.png`*

## Robustness Sweep Artifacts

- `results/metrics_robust_answer_noise.csv`
- `results/metrics_robust_mismatch.csv`
- `results/robust_answer_noise_deltas.png`
- `results/robust_mismatch_deltas.png`

## Generalization Artifacts

- `results/metrics_generalization_templates.csv`
- `results/generalization_templates_plot.png`
- `results/metrics_scaleK.csv`
- `results/scaleK_plot.png`
